-- Rejilla de la pantalla de nombres con letras acentuadas (Gold)
-- upper: fila superior (Shift pulsado), lower: fila inferior
return {
  upper = {
    { "A", "B", "C", "D", "E", "F", "G", "H", "I" },
    { "J", "K", "L", "M", "N", "O", "P", "Q", "R" },
    { "S", "T", "U", "V", "W", "X", "Y", "Z", " " },
    { "Á", "É", "Í", "Ó", "Ú", "Ñ", "Ü", "(", ")" },
    { "-", "?", "!", "¿", "¡", "/", ".", ",", "ED" },
    { "lower case" },
  },
  lower = {
    { "a", "b", "c", "d", "e", "f", "g", "h", "i" },
    { "j", "k", "l", "m", "n", "o", "p", "q", "r" },
    { "s", "t", "u", "v", "w", "x", "y", "z", " " },
    { "á", "é", "í", "ó", "ú", "ñ", "ü", "(", ")" },
    { "-", "?", "!", "¿", "¡", "/", ".", ",", "ED" },
    { "UPPER CASE" },
  },
}

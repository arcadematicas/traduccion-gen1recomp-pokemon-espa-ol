# Changelog

## 0.2.0 (2026-08-20)

### Added
- Traduccion de cadenas del motor (batalla, objetos, UI) via `strings.lua`
- Etiquetas de estado de batalla en espanol (`status_labels.lua`)
- Rejilla de pantalla de nombres con letras acentuadas (`naming.lua`)
- Traduccion de emisoras de radio del Pokegear (`radio_channels.lua`)
- Traduccion de lugares del mapa (`landmarks.lua`)
- Traduccion de decoraciones de habitacion (`decorations.lua`)
- Soporte para regitras Gen 2-only: radio_channels, landmarks, decorations, status_labels, strings
- Formato de mod actualizado a API v2 con `mod.card`

### Changed
- Manifest.json actualizado a formato nuevo (`language: true`, `category: LANGUAGE`)
- main.lua actualizado para registrar todas las nuevas regitras

## 0.1.0 (2026-08-19)

### Added
- Traduccion inicial de dialogos (3042 entradas)
- Traduccion de nombres de Pokemon (1007 entradas)
- Traduccion de objetos (217 entradas)
- Traduccion de movimientos (252 entradas)
- Traduccion de entrenadores (57 entradas)
- Fuente personalizada con glifos espanoles
- Soporte para caracteres acentuados via charmap
